# 💻 03. HTML & Bootstrap > oefening 04

## 🛠️ opdrachten

### `index.html` maken

- [ ] Maak een nieuw bestand genaamd `index.html` aan in deze map.
- [ ] Open het bestand.
- [ ] Voeg de [Bootstrap meta-informatie](/README.md) toe aan je `head`-element om Bootstrap te kunnen gebruiken.

### voorbeeld namaken

- [ ] Maak het voorbeeld na met behulp van een [semantische tabel](https://apwt.gitbook.io/g_webtechnologie/html/html-tabellen).
- [ ] **tip:** (Bootstrap) Deze tabel heeft een _border_ en de _thead_ is _donker_.

![Alt text](image.png)
